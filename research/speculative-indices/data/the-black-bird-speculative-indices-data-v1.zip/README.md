# Speculative Indices — Data Package

**Work:** The Black Bird
**Author:** Mohammad Zare
**Version:** v1

This package contains the data underlying the speculative indices published in the Research Annex of *The Black Bird*.

## Files

| File | Description |
|------|-------------|
| `relational_indices_bundle.json` | Complete machine-readable bundle of all indices, matrices, and metadata |
| `rno_fo_incidence_matrix.csv` | A matrix (4 × 18): RNO–FO incidence |
| `object_incidence_rno.csv` | OI_N: RNO Field Breadth |
| `object_incidence_fo.csv` | OI_F: Field Object Research Recurrence |
| `rno_overlap_matrix.csv` | RT_NN: RNO–RNO Field Overlap (A Aᵀ) |
| `fo_research_coincidence_matrix.csv` | RT_FF^N: FO–FO Research Co-incidence (Aᵀ A) |
| `fo_relo_participation.csv` | MI_R: Mediational Incidence / RelO Participation |
| `fo_relo_thickness_matrix.csv` | RT_FF^R: FO–FO RelO-Mediated Thickness (B Bᵀ) |
| `SHA256SUMS.txt` | SHA-256 checksums for all files in this package |

## Object Types

- **RNO** — Research Note Object (4 nodes)
- **MNO** — Mapping Note Object (2 nodes)
- **FO** — Field Object (18 nodes)
- **NameO** — Name Object (4 nodes)
- **RefO** — Reference Object (10 nodes)
- **RelO** — Relation Object (12 nodes)
- **Total** — 50 nodes

## Index Formulas

| Index | Formula |
|-------|---------|
| RNO Field Breadth | OI_N(n) = Σ_f A[n,f] |
| Field Object Research Recurrence | OI_F(f) = Σ_n A[n,f] |
| RNO–RNO Field Overlap | RT_NN = A Aᵀ |
| FO–FO Research Co-incidence | RT_FF^N = Aᵀ A |
| Mediational Incidence | MI_R(f) = Σ_r B[f,r] |
| FO–FO RelO-Mediated Thickness | RT_FF^R = B Bᵀ |

## Primary Matrix (A)

- Dimensions: 4 × 18 (RNO × FO)
- Positive incidents: 23
- Density: 31.94%

## License

Data is released for research use. The primary work, *The Black Bird*, remains under its original rights. See RIGHTS.md in the main repository.
